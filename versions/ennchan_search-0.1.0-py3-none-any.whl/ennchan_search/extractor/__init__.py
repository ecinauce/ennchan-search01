"""Content extraction functionality."""

from ennchan_search.extractor.extractorModel import WebResultExtractor
