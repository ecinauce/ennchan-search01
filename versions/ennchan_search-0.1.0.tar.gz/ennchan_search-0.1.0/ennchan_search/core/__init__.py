"""Core search functionality."""

from ennchan_search.core.model import BraveSearchEngine
from ennchan_search.core.interfaces import SearchEngine, ResultExtractor
