"""Utility functions for the search module."""
